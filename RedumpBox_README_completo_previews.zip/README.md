<div align="center">

<img src="assets/redumpbox-icon.png" alt="Ícone do Redump Box" width="150">

# Redump Box

### Seu catálogo de ports, jogos, emuladores e apps para Android

[![Android](https://img.shields.io/badge/Android-7.0%2B-30BFAE?style=flat-square&logo=android&logoColor=white)](#compatibilidade)
[![Release](https://img.shields.io/github/v/release/will-tool/Redump-Box?display_name=tag&style=flat-square&color=2CBFC1)](https://github.com/will-tool/Redump-Box/releases)
[![Downloads](https://img.shields.io/github/downloads/will-tool/Redump-Box/1.0/total?style=flat-square&color=153E4D)](https://github.com/will-tool/Redump-Box/releases/tag/1.0)

**[Baixar APK](https://github.com/will-tool/Redump-Box/releases/download/1.0/redumpbox_beta_1.0_arm64.apk)**　·　[Ver todas as versões](https://github.com/will-tool/Redump-Box/releases)　·　[Telegram](https://t.me/redumpbox)

</div>

---

## Um só lugar para explorar

Redump Box organiza um catálogo de jogos, ports, emuladores e aplicativos auxiliares. Pesquise, filtre por categoria e abra os detalhes para consultar as informações e os links disponíveis para cada item.

> O catálogo e os links podem mudar ao longo do tempo. Confira os detalhes e a origem de cada download antes de instalar.

## Por dentro do app

<div align="center">

<table>
<tr>
<td align="center" width="33%"><strong>Início</strong><br><img src="assets/previews/inicio.jpg" alt="Tela inicial do Redump Box" width="230"></td>
<td align="center" width="33%"><strong>Apps</strong><br><img src="assets/previews/apps.jpg" alt="Catálogo de aplicativos" width="230"></td>
<td align="center" width="33%"><strong>Emuladores</strong><br><img src="assets/previews/emuladores.jpg" alt="Catálogo de emuladores com filtros" width="230"></td>
</tr>
</table>

</div>

## O que dá para fazer

- **Explorar catálogos:** navegue por ports, jogos, emuladores e apps auxiliares.
- **Encontrar itens:** use busca e filtros disponíveis em cada seção.
- **Consultar detalhes:** veja descrição, plataforma, versão e outras informações cadastradas.
- **Guardar favoritos:** reúna os itens que quer encontrar de novo.
- **Acompanhar novidades:** consulte a área de novidades e as notificações do aplicativo.
- **Personalizar a aparência:** escolha entre os temas Mar, Escuro e Claro.
- **Gerenciar downloads:** abra a fila de downloads e acompanhe o andamento.

## Instalação do APK

1. Abra a página de [Releases](https://github.com/will-tool/Redump-Box/releases).
2. Escolha a versão e baixe o arquivo `.apk` anexado.
3. Abra o APK no Android. Se solicitado, autorize a instalação para o navegador ou gerenciador de arquivos usado.
4. Siga as instruções do Android para concluir a instalação.

### Compatibilidade

A versão 1.0 disponibilizada aqui foi compilada para **ARM64 (`arm64-v8a`)** e requer **Android 7.0 ou superior**. Aparelhos com outra arquitetura podem não instalar essa versão.

## Como funcionam as atualizações

As versões novas são publicadas em [Releases](https://github.com/will-tool/Redump-Box/releases). Quando uma atualização obrigatória estiver habilitada, o Redump Box mostrará o aviso correspondente e direcionará o usuário para atualizar. A confirmação de instalação é feita pelo Android.

Para atualizar uma instalação existente, a nova versão precisa manter o mesmo pacote e ser assinada com a mesma chave de release. Se o sistema rejeitar a atualização, não desinstale a versão atual antes de confirmar que tem como reinstalá-la e recuperar seus dados.

## Dúvidas rápidas

<details>
<summary><strong>O Android bloqueou a instalação. O que faço?</strong></summary>

Se você decidiu instalar o APK, permita a instalação para a origem indicada nas configurações do Android e volte ao instalador. Baixe somente da página oficial de Releases deste repositório.

</details>

<details>
<summary><strong>Por que o aparelho diz que o app não é compatível?</strong></summary>

O APK desta versão é ARM64. Confira se o processador do aparelho oferece suporte a `arm64-v8a` e se a versão do Android é 7.0 ou superior.

</details>

<details>
<summary><strong>O link de um item não funciona?</strong></summary>

Os links do catálogo podem depender de serviços externos e podem mudar ou ficar indisponíveis. Confira a página de origem do item e evite instalar arquivos que não consiga verificar.

</details>

## Avisos

Redump Box é um catálogo e cliente Android. Os nomes, marcas, imagens, jogos e aplicativos de terceiros pertencem aos seus respectivos titulares. A presença de um item no catálogo não significa que Redump Box seja seu desenvolvedor ou titular. Obtenha e distribua somente conteúdo para o qual você tenha autorização e respeite as leis e os termos aplicáveis.

Este repositório apresenta o aplicativo e distribui seus APKs nas Releases; **o código-fonte não está publicado aqui**. Instale APKs por sua própria decisão e sempre confira se o arquivo veio da Release oficial.

## Comunidade e contato

- **Telegram:** [t.me/redumpbox](https://t.me/redumpbox)
- **Versões e downloads:** [Releases do Redump Box](https://github.com/will-tool/Redump-Box/releases)
- **Ajuda e problemas:** abra uma [Issue](https://github.com/will-tool/Redump-Box/issues) descrevendo o modelo do aparelho, versão do Android e o que aconteceu. Não publique e-mail, UID, tokens ou outros dados pessoais.

---

<div align="center">

**Redump Box · feito para explorar no Android**

</div>
